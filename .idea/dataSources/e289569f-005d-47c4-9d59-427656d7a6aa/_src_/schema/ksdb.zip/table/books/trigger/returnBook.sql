CREATE TRIGGER `returnBook`
AFTER UPDATE ON `books`
FOR EACH ROW
  BEGIN
    UPDATE lender
    SET amount = ifnull(lender.amount ,0)-1
    WHERE id = old.isLend;
  END