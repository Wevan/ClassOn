CREATE TRIGGER `subook`
BEFORE UPDATE ON `lender`
FOR EACH ROW
  BEGIN
  IF new.amount>5 THEN SET new.amount:=5;
    END IF;
END